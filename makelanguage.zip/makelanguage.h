#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <vector>

using namespace std;
string code = "";

class Compiler {
public:
	static void PrintLine(string What) {
		code += "echo " + What + "\n";
	}
	static void Print(string What) {
		code += "echo -n \"" + What + "\"\n";
	}
	static void WriteOutput(string FileName) {
		ofstream FileVariable(FileName);
		FileVariable << code;
		FileVariable.close();
	}
};

#ifndef VARIABLEPREFIX
string VARIABLEPREFIX = "$";
#endif

#ifdef VARIABLESIZE
string VariableKeys[VARIABLESIZE];
string VariableVals[VARIABLESIZE];
int pointer = 0;
#else
#define VARIABLESIZE 200
string VariableKeys[200];
string VariableVals[200];
int pointer = 0;
#endif

class Interpreter {
public:
	static int GetIndexOfVariable(string Key) {
	    for(int i = 0; i < VARIABLESIZE; i++) {
	        if(VariableKeys[i] == Key)
	            return i;
	    }
	    return -1;
	}
	static bool IsInVariables(std::string Value) {
	    for(int i = 0; i < VARIABLESIZE; i++) {
	        if(Value == VariableKeys[i]) {
	            return true;
	        }
	    }
	    return false;
	}
	static void VariableInsert(string Key, string Value) {
		if(IsInVariables(Key)) {
       		VariableVals[GetIndexOfVariable(Key.substr(VARIABLEPREFIX.length() - 1))] = Value;
       	} else {
			VariableKeys[pointer] = Key;
			VariableVals[pointer] = Value;
			pointer++;
		}
	}
	static void GetVariables() {
		for(int i = 0; i < pointer; i++) {
			std::cout << VariableKeys[i] << ": " << VariableVals[i] << std::endl;
		}
	}
	static bool ReplaceVariables(string& Line) {
		// bool replaceString(std::string& str, const std::string& from, const std::string& to) {
		for(int i = 0; i < pointer; i++) {
		    size_t start_pos = Line.find(VARIABLEPREFIX + VariableKeys[i]);
		    if(start_pos == std::string::npos)
		        continue;
		    Line.replace(start_pos, (VARIABLEPREFIX + VariableKeys[i]).length(), VariableVals[i]);
		}
	    return true;
	}
	static void ReadLines(string FileName, void (*Function)(int, string)) {
		ifstream FileVariable(FileName);
		string TextLine;
		int Line = 0;
		while (getline (FileVariable, TextLine)) {
		  Function(Line, TextLine);
		  Line++;
		}
		FileVariable.close();
	}
	static bool IsVariableSet(string Line, string SetVariablePrefix = "var") {
        if(Line.rfind(SetVariablePrefix, 0) == 0) 
			return true;
		else
			return false;
	}
	static void SetVariable(string Line) {
		string VariableName = SplitSpace(Line)[1];
		string VariableValue = SplitSpace(Line)[3];
		VariableInsert(VariableName, VariableValue.substr(0, VariableValue.length() - 1));
	}
	static bool IsComment(string Line, string Comment = "//") {
		if(Line.rfind(Comment, 0) == 0) {
			return true;
		} else if(Line == "") {
			return true;
		} else {
			return false;
		}
	}
	static bool IsCommand(string Line, string Command) {
    	return Line.rfind(Command, 0) == 0;
    }
    static vector<string> Split(string String) {
		string str = String + ',';
		string All;
		vector<string> v;
		for( size_t i=0; i<str.length(); i++){
		    char c = str[i];
		    if( c == ',' ){
		        v.push_back(All);
		        All = "";
		    }else if(c == '\"' ){
		        i++;
		        while( str[i] != '\"' ){ All += str[i]; i++; }
		    }else{
		        All += c;
		    }
		}
		return v;
	}
	static vector<string> SplitSpace(string String) {
		string str = String + ' ';
		string All;
		vector<string> v;
		for( size_t i=0; i<str.length(); i++){
		    char c = str[i];
		    if( c == ' ' ){
		        v.push_back(All);
		        All = "";
		    }else if(c == '\"' ){
		        i++;
		        while( str[i] != '\"' ){ All += str[i]; i++; }
		    }else{
		        All += c;
		    }
		}
		return v;
	}
    static string GetArguments(string Line, string Command) {
    	int Lenght = Command.length();
    	int Lenght2 = Line.length() - 2;
    	return Line.substr(Lenght + 1).substr(0, Lenght2 - Lenght - 1);
    }
    static vector<string> Arguments(string Line, string Command) {
    	int Lenght = Command.length();
    	int Lenght2 = Line.length() - 2;
    	string arg = Line.substr(Lenght + 1).substr(0, Lenght2 - Lenght - 1);
    	string str = arg + ',';
		string All;
		vector<string> v;
		for( size_t i=0; i<str.length(); i++){
		    char c = str[i];
		    if( c == ',' ){
		        v.push_back(All);
		        All = "";
		    }else if(c == '\"' ){
		        i++;
		        while( str[i] != '\"' ){ All += str[i]; i++; }
		    }else{
		        All += c;
		    }
		}
		return v;
    }
};