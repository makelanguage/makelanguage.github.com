#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <vector>

using namespace std;
string code = "";

class Compiler {
public:
	static void PrintLine(string What) {
		code += "echo " + What + "\n";
	}
	static void Print(string What) {
		code += "echo -n \"" + What + "\"\n";
	}
	static void WriteOutput(string FileName) {
		ofstream FileVariable(FileName);
		FileVariable << code;
		FileVariable.close();
	}
};

class Interpreter {
public:
	static void ReadLines(string FileName, void (*Function)(int, string)) {
		ifstream FileVariable(FileName);
		string TextLine;
		int Line = 0;
		while (getline (FileVariable, TextLine)) {
		  Function(Line, TextLine);
		  Line++;
		}
		FileVariable.close();
	}
	static bool IsComment(string Line, string Comment = "//") {
		if(Line.rfind(Comment, 0) == 0) {
			return true;
		} else if(Line == "") {
			return true;
		} else {
			return false;
		}
	}
	static bool IsCommand(string Line, string Command) {
    	return Line.rfind(Command, 0) == 0;
    }
    static vector<string> Split(string String) {
		string str = String + ',';
		string All;
		vector<string> v;
		for( size_t i=0; i<str.length(); i++){
		    char c = str[i];
		    if( c == ',' ){
		        v.push_back(All);
		        All = "";
		    }else if(c == '\"' ){
		        i++;
		        while( str[i] != '\"' ){ All += str[i]; i++; }
		    }else{
		        All += c;
		    }
		}
		return v;
	}
    static string GetArguments(string Line, string Command) {
    	int Lenght = Command.length();
    	int Lenght2 = Line.length() - 2;
    	return Line.substr(Lenght + 1).substr(0, Lenght2 - Lenght - 1);
    }
    static vector<string> Arguments(string Line, string Command) {
    	int Lenght = Command.length();
    	int Lenght2 = Line.length() - 2;
    	string arg = Line.substr(Lenght + 1).substr(0, Lenght2 - Lenght - 1);
    	string str = arg + ',';
		string All;
		vector<string> v;
		for( size_t i=0; i<str.length(); i++){
		    char c = str[i];
		    if( c == ',' ){
		        v.push_back(All);
		        All = "";
		    }else if(c == '\"' ){
		        i++;
		        while( str[i] != '\"' ){ All += str[i]; i++; }
		    }else{
		        All += c;
		    }
		}
		return v;
    }
};